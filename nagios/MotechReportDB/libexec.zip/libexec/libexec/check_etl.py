#!/usr/bin/python

import sys
from datetime import datetime,timedelta

STATUS_OK=0
STATUS_WARNING=1
STATUS_CRITICAL=2
input_file=str(sys.argv[1])
def request_alerts():
	global input_file
	status = STATUS_OK
	current_time = datetime.now()
	current_time_str = current_time.strftime("%Y-%m-%d")
	try:	
		with open(input_file) as input_file:
			for line in input_file:
				if current_time_str in line:	#find the line with current date datetime and scan the line from this line onwards till we find error
					break
		
			for line in input_file:
				if line.startswith('Error occured in'):
					status = STATUS_CRITICAL
					print line
					break

	except Exception as ex :
		print ex
		status = STATUS_CRITICAL
	if (status == STATUS_OK):
		print "ETL executed"
	sys.exit(status)

if __name__ == "__main__":
	request_alerts()
