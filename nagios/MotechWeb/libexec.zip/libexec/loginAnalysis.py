#!/usr/bin/python

import requests
import sys
import os.path
import time
from datetime import datetime,timedelta
import re

status=0
Critical_Count = 0
High_Count = 0
Medium_Count = 0
Low_Count = 0
Fresh_Alert=0
STATUS_OK=0
STATUS_WARNING=1
STATUS_CRITICAL=2
#tomcatpath= os.environ['CATALINA_HOME']
tomcatpath="/usr/local/tomcat/apache-tomcat-7.0.57"
#print tomcatpath
input_file = tomcatpath+"/logs/catalina.out"
output_file = "/tmp/catlinaexceptionoutput.log"
#print input_file
if os.path.exists(output_file):
    os.remove(output_file)

#current_time = datetime.now()-timedelta(hours=1)
#print current_time
#sys.exit(status)
def request_alerts():
  global output_file
  global input_file
  flag = True
  status = STATUS_OK
  current_time = datetime.now()-timedelta(hours=1)
  #current_time_str = current_time.strftime("%h %d, %Y %H")
  current_time_str = current_time.strftime("%Y-%m-%d %H")
  #print current_time_str
  #sys.exit(status)
# output_file = output_file + current_time_str
  try:  
    _file = open(output_file,"w")
    with open(input_file) as input_file:
      while flag:
        for line in input_file:
          #print 'executing the script.. Please wait.....'
          if current_time_str in line:  #find the line with required datetime.
            flag = False
            _file.write(line+'\n')
            break
        if flag:
          #print "TimeStamp : <"+ current_time_str + "> does not exists in"+tomcatpath+"/logs/catalina.out"
          _file.close()
          flag = False
          #sys.exit(status)
      
      
      for line in input_file:
        matching_strs = '[0-9][0-9]:[0-9][0-9]:[0-9][0-9],[0-9][0-9][0-9]\s'
        if line.startswith('Exception') or re.findall(matching_strs + 'ERROR',line):
          _file.write(line+'\n******************************************************************************************\n')
          status = STATUS_CRITICAL
          break
  
      for line in input_file:
        if re.findall(matching_strs + 'ERROR [LOGGER] Error end:',line) or re.findall(matching_strs + 'ERROR',line):
          status = STATUS_CRITICAL
          break
        else:
          _file.write(line+'\n')
  except Exception as ex :
    #print ex
    status = STATUS_CRITICAL
  #print status
  if(status>0):
    print "EXCEPTION in CATALINA LOGS"
    os.system("scp " + output_file+ " grameen@192.168.200.4:/tmp/")
  else:
    error_message="Checked for "+ current_time_str + " Hours and  NO EXCETPTION IN CATALINA LOGS"
    print error_message
  sys.exit(status)
      


if __name__ == "__main__":
  request_alerts()
  
  


