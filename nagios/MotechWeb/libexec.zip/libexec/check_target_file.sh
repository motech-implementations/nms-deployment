STATE_OK=0              # define the exit code if status is OK
STATE_WARNING=1         # define the exit code if status is Warning (not really used)
STATE_CRITICAL=2        # define the exit code if status is Critical
STATE_UNKNOWN=3         # define the exit code if status is Unknown
export PATH=$PATH:/usr/local/bin:/usr/bin:/bin # Set path
date=`date +%Y%m%d`
file=/usr/local/imi/obd/OBD_NMS_$date*.csv

if [ $? = 0 ]; then
        TargetFILE=$(file /usr/local/imi/obd/OBD_NMS_$date*.csv|cut -d'/' -f6| cut -d ':' -f1)
        echo -e "MOTECH sent $TargetFILE TO IMI                     "
        echo -e "CIRLCE WISE DATA      "
        echo -e "  TOTAL CIRCLE"
	awk -F ',' '{print $10}' /usr/local/imi/obd/OBD_NMS_$date*.csv | sort | uniq -c|grep -v Circle
        exit 0;
else
	echo "ValueIS $?"
	exit 2;
fi	
